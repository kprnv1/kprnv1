package searchengine.services.responses;

public class TrueResponseService implements ResponseService {

    @Override
    public boolean getResult() {
        return true;
    }
}
