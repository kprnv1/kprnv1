package searchengine.services.responses;

public interface ResponseService {

    boolean getResult();
}
