package searchengine.services;

import searchengine.services.responses.StatisticResponseService;

public interface StatisticsService {
    StatisticResponseService getStatistics();
}
